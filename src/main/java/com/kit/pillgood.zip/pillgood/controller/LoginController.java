package com.kit.pillgood.controller;

import com.kit.pillgood.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
public class LoginController {

    private final UserService userService;

    @Autowired
    public LoginController(UserService userService) {
        this.userService = userService;
    }

    public void login() {
        // 로그인
    }

    public void handleLoginSuccess() {
        // 로그인 성공 작업
    }

    public void handleLoginFailure() {
        // 로그인 실패 작업
    }

}
