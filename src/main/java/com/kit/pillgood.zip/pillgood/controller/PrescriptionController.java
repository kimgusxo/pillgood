package com.kit.pillgood.controller;

import com.kit.pillgood.persistence.dto.PrescriptionDTO;
import com.kit.pillgood.service.PrescriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/prescription")
public class PrescriptionController {
    private final PrescriptionService prescriptionService;

    @Autowired
    public PrescriptionController(PrescriptionService prescriptionService) {
        this.prescriptionService = prescriptionService;
    }

    @GetMapping("/search/{group-member-index}")
    public List<PrescriptionDTO> getPrescriptionsByGroupMemberIndex(@PathVariable(name="group-member-index") Long groupMemberIndex) {

    }

    @PostMapping("/create/image-upload")
    public PrescriptionDTO createPrescriptionByImage(@ModelAttribute MultipartFile prescriptionImage) {

    }

    @DeleteMapping("/delete/{prescription-index}")
    public PrescriptionDTO deletePrescriptionByPrescriptionIndex(@PathVariable(name="prescription-index") Long prescriptionIndex) {

    }
}
