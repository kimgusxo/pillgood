package com.kit.pillgood.controller;

import com.kit.pillgood.persistence.dto.PillDTO;
import com.kit.pillgood.persistence.dto.SearchingConditionDTO;
import com.kit.pillgood.service.PillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pill")
public class PillController {
    private final PillService pillService;

    @Autowired
    public PillController(PillService pillService) {
        this.pillService = pillService;
    }

    @GetMapping("/search/{pill-index}")
    public PillDTO getPillByPillIndex(@PathVariable(name="pill-index") Long pillIndex) {

    }

    @GetMapping("/search/pills")
    public List<PillDTO> getSearchingPills(@ModelAttribute SearchingConditionDTO searchingConditionDTO) {

    }
}
