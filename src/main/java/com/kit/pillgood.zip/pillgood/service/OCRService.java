package com.kit.pillgood.service;

import com.kit.pillgood.domain.Prescription;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@NoArgsConstructor
public class OCRService {

    public Prescription extractPrescriptionTextFromImage(MultipartFile imageFile) {
        // 처방전 이미지에서 텍스트 추출
    }

}
