package com.kit.pillgood.service;

import com.kit.pillgood.domain.Disease;
import com.kit.pillgood.repository.DiseaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DiseaseService {

    private final DiseaseRepository diseaseRepository;

    @Autowired
    public DiseaseService(DiseaseRepository diseaseRepository) {
        this.diseaseRepository = diseaseRepository;
    }

//    public Disease searchDiseaseByDiseaseCode(String diseaseCode) {
//
//    }
}
