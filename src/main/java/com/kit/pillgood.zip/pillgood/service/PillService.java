package com.kit.pillgood.service;

import com.kit.pillgood.domain.Pill;
import com.kit.pillgood.repository.PillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PillService {
    private final PillRepository pillRepository;

    @Autowired
    public PillService(PillRepository pillRepository) {
        this.pillRepository = pillRepository;
    }

    public Pill searchPillByPillIndex(Long pillIndex) {
        // 약 코드로 약을 검색함
    }

    public Pill searchPillByPillName(String pillName) {
        // 약 이름으로 약을 검색함
    }

    public List<Pill> searchPillByAttributeOfPill(SearchingConditionDTO searchingConditionDTO) {
        // 약 특징 정보들로 약 리스트를 검색함
    }
}
