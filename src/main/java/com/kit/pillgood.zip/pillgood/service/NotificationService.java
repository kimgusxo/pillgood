package com.kit.pillgood.service;

import com.kit.pillgood.domain.Notification;
import com.kit.pillgood.repository.GroupMemberRepository;
import com.kit.pillgood.repository.NotificationRepository;
import com.kit.pillgood.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {
    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final GroupMemberRepository groupMemberRepository;
    private final FirebaseMessaging firebaseMessaging;

    @Autowired
    public NotificationService(NotificationRepository notificationRepository,
                               UserRepository userRepository,
                               GroupMemberRepository groupMemberRepository,
                               FirebaseMessaging firebaseMessaging) {
        this.notificationRepository = notificationRepository;
        this.userRepository = userRepository;
        this.groupMemberRepository = groupMemberRepository;
        this.firebaseMessaging  = firebaseMessaging;
    }

    public void createAllNotification() {
        // 모든 알림 생성
    }

    public List<Notification> searchNotificationByUserIndex(Long userIndex) {
        // 유저 인덱스로 알림 검색
    }

    public Notification updateNotification(NotificationDTO notificationDTO) {
        // 알림 수정
    }

    public void sendAutoPushMessageNotification() {
        // 자동 메세지 전송
    }

    public void sendCreatedPrescriptionNotification(Long userIndex, Long groupMemberIndex) {
        // 처방전 알림 생성 후 전송
    }
}
